git init
git remote add origin https://github.com/yedotimahesh/SMART-ATTANDANCE-SYSTEM-.git
git remote -v  --force
git add . --force
git commit -m "upload1"


git push -f origin master